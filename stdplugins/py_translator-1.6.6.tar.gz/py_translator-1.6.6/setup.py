"""A setuptools based setup module.

See:
https://packaging.python.org/tutorials/distributing-packages/#classifiers
https://packaging.python.org/en/latest/distributing.html
https://github.com/pypa/sampleproject
"""


from setuptools import setup, find_packages
from codecs import open


setup(
    name='py_translator',  # Required
    version='1.6.6',  # Required
    description='The end goal is a simple application for translating text in the terminal. Text can be generated interactively or programmatically in the shell environment.',  # Required
    long_description=open('README.md', encoding="utf-8").read(),
    long_description_content_type='text/markdown',  # This is important!
    keywords='pypi python3 translate google api html text language translation translator cloud',

    url='https://github.com/markolofsen/py_translator',  # Optional
    author='Mark',  # Optional
    author_email='kupi@kupi.net',  # Optional
    download_url='https://github.com/markolofsen/py_translator',


    # This field corresponds to the "Project-URL" metadata fields:
    # https://packaging.python.org/specifications/core-metadata/#project-url-multiple-use
    # project_urls={  # Optional
    #     'Bug Reports': 'https://github.com/markolofsen/py_translator/issues',
    #     # 'Funding': '__LINK_FUNDING__',
    #     'Donations': 'https://kupi.net',
    #     'Source': 'https://kupi.net',
    # },


    # https://pypi.python.org/pypi?%3Aaction=list_classifiers
    classifiers=['Development Status :: 3 - Alpha', 'Development Status :: 4 - Beta', 'Development Status :: 5 - Production/Stable', 'Development Status :: 6 - Mature', 'Development Status :: 7 - Inactive'],

    license='Apache License 2.0',

    # You can just specify package directories manually here if your project is
    # simple. Or you can use find_packages().
    packages=find_packages(
        # include=['data'],
        # exclude=['scripts','sample']
    ),  # Required


    include_package_data=True,
    zip_safe=False,
    install_requires=[
            # 'Scrapy>=1.1.0',
            # 're', 'threading', 'time', 'html', 'random',
            ],
    extras_require={
            ':python_version >= "3.0"': ['python-slugify', 'langdetect', 'beautifulsoup4', 'lxml'],
            },

    entry_points={
        'console_scripts': ['TokenAcquirer = py_translator.gtoken:TokenAcquirer', 'Translated = py_translator.models:Translated', 'Translator = py_translator.client:Translator', 'TimeoutAdapter = py_translator.adapters:TimeoutAdapter', 'TEXTLIB = py_translator.html_connector:TEXTLIB'],
            # 'console_scripts': [
            #     '['TokenAcquirer = py_translator.gtoken:TokenAcquirer', 'Translated = py_translator.models:Translated', 'Translator = py_translator.client:Translator', 'TimeoutAdapter = py_translator.adapters:TimeoutAdapter', 'TEXTLIB = py_translator.html_connector:TEXTLIB']',
            # ],
            },


    setup_requires=['setuptools'],

    # If there are data files included in your packages that need to be
    # installed, specify them here.
    #
    # If using Python 2.6 or earlier, then these have to be included in
    # MANIFEST.in as well.
    package_data={  # Optional
            # 'sample': ['package_data.dat'],
    },

    # In this case, 'data_file' will be installed into '<sys.prefix>/my_data'
    data_files=[
        # ('libs', [
        #     'data/libs/TEXTLIB/init.py',
        # ]),
        # ('data', [
        #     'data/data_file',
        # ]),
    ],  # Optional

)
